function cp_calculatedfieldsf_insertForm() {
    send_to_editor('[CP_CALCULATED_FIELDS]');
}